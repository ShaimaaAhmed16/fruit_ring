<?php $__env->startSection('content'); ?>

    <section class="container text-center pt-3">
        <img src="<?php echo e(asset('front/images/tt.png')); ?>" alt="" width="150">
    </section>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger text-right">
            <ul class="">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <section class="signin">
        <div class="card pt-3">
            <form class="container" method="post" action="<?php echo e(route('register.client')); ?>">
                <?php echo csrf_field(); ?>
                <div class="text-center mb-2">
                    <small>تسجيل حساب جديد</small>
                </div>

                <div class="form-group">

                    <input type="text" class="form-control text-right" placeholder="الإسم بالكامل" name="name" value="<?php echo e(old('name')); ?>">
                </div>
                <div class="form-group ">

                    <input type="email" class="form-control text-right" placeholder="البريد الالكترونى" name="email" <?php echo e(old('email')); ?>>
                </div>
                <div class="form-group">

                    <input type="tel" class="form-control text-right" placeholder="رقم الجوال" name="phone" <?php echo e(old('phone')); ?>>
                </div>
                <div class="form-group">

                    <input type="password" class="form-control text-right" placeholder="كلمة المرور" name="password">
                </div>
                <div class="form-check text-center mt-4 mb-4">
                    <label class="form-check-label mr-4">
                        أوافق على الشروط والقوانين
                    </label>
                    <input class="form-check-input mr-3" type="checkbox" value="أوافق على الشروط والقوانين" name="ok">

                </div>
                <div class="text-center">
                    <button type="submit" id="myBtn1" class="btn btn-block text-white bg-light-green mb-1">تسجيل حساب جديد</button>
                </div><br>
                <hr>
                <div class="d-flex justify-content-around ">
                    <a href="#">
                        <i class="fab fa-google fa-2x text-danger"></i>
                    </a>
                    <a href="#">
                        <i class="fab fa-twitter fa-2x text-primary"></i>
                    </a>
                    <a href="#">
                        <i class="fab fa-facebook fa-2x text-blue"></i>
                    </a>
                </div>

            </form>
        </div>
    </section>



    
        
    

    
        
    

    
        
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\system\fruit_ring\resources\views/front/register.blade.php ENDPATH**/ ?>