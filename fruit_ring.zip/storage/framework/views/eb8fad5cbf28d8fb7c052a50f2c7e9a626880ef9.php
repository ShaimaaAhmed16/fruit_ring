<header class="header card fixed-top bg-light-green">
    <div class="container pt-2 ">
        <div class="row">
            <div class="col-8">
                <h6 class="text-right text-white">الصفحة الشخصية</h6>
            </div>
            <div class="col-4 text-right">
                <a href="#" class="text-white">
                    <i class="fas fa-bars" onclick="openNav()"></i>
                </a>
            </div>
            <div id="mySidenav" class="sidenav">
                <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
                <?php if(auth()->guard('client-web')->check()): ?>
                    <a href="updateinfo.html" class="user">
                        <img src="<?php echo e(asset('front/images/user-icon.png')); ?>" alt="" width="40" class="user-icon">
                        <i class="fas fa-plus"></i>
                    </a>
                <?php endif; ?>
                <a href="main.html">
                    <span>الرئيسية</span>
                    <i class="fas fa-store-alt pl-2"></i>
                </a>
                <a href="<?php echo e(route('about')); ?>">
                    <span>من نحن</span>
                    <i class="fas fa-apple-alt pl-2"></i>
                </a>
                <a href="<?php echo e(route('bank')); ?>">
                    <span>بيانات الحسابات البنكية</span>
                    <i class="fas fa-dollar-sign pl-2"></i>
                </a>
                <?php if(auth()->guard('client-web')->check()): ?>
                    <a href="<?php echo e(route('profile.client',auth('client-web')->user()->id)); ?>">
                        <span>صفحتى الشخصية </span>
                        <i class="far fa-user-circle pl-2"></i>
                    </a>
                    <a href="#">
                        <span>قائمة رغباتى </span>
                        <i class="far fa-heart pl-2"></i>
                    </a>
                    <a href="shopcart.html">
                        <span>سلة التسوق </span>
                        <i class="fas fa-shopping-basket pl-2"></i>
                    </a>
                <?php else: ?>
                    <a href="<?php echo e(route('register.client')); ?>">
                        <span>تسجيل حساب جديد </span>
                        <i class="fas fa-shopping-basket pl-2"></i>
                    </a>
                    <a href="<?php echo e(route('login.client')); ?>">
                        <span>تسجيل الدخول </span>
                        <i class="fas fa-shopping-basket pl-2"></i>
                    </a>
                <?php endif; ?>
                <a href="<?php echo e(route('contact.client')); ?>">
                    <span>اتصل  بنا </span>
                    <i class="fas fa-phone-volume pl-2"></i>
                </a>
                <a href="#">
                    <span>مشاركة البيانات</span>
                    <i class="fas fa-share-alt pl-2"></i>
                </a>
                <a href="#">
                    <span>تقييم التطبيق </span>
                    <i class="fas fa-star-half-alt pl-2"></i>
                </a>
                <?php if(auth()->guard('client-web')->check()): ?>
                    <a href="<?php echo e(route('login.client')); ?>">
                        <span>خروج </span>
                        <i class="fas fa-sign-out-alt pl-2"></i>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>

</header>

<?php $__env->startSection('content'); ?>
    <div style="background:whitesmoke; margin-top: 100px" >
        <div class="mt-3">
            <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <section class="update container text-center">
            <div class="card">
                <div class="row">
                    <div class="col-12">
                        <?php if(auth()->guard('client-web')->user()->image): ?>
                            <img src="<?php echo e(asset(auth()->guard('client-web')->user()->image)); ?> " alt="" width="100">
                       <?php else: ?>
                            <img src="<?php echo e(asset('front/images/user-icon.png')); ?>" alt="" width="100">
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <form method="post" action="<?php echo e(url('profile-update/'.auth()->guard('client-web')->user()->id)); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group text-right">
                    <label for="Name" class="text-light-green">الاسم</label>
                    <?php echo Form::text('full_name',auth()->guard('client-web')->user()->full_name,[
                    'class'=>'form-control text-right',
                    ]); ?>

                </div>


                <div class="form-group text-right">
                    <label for="Phone" class="text-light-green">رقم الجوال</label>
                    <?php echo Form::text('phone',auth()->guard('client-web')->user()->phone,[
                        'class'=>'form-control text-right',
                    ]); ?>

                </div>
                <div class="form-group text-right">
                    <label for="email" class="text-light-green">البريد الالكترونى</label>
                    <?php echo Form::text('email',auth()->guard('client-web')->user()->email,[
                     'class'=>'form-control text-right',
                    ]); ?>

                </div>
                <div class="form-group text-right">
                    <label  class="text-light-green">العنوان</label>
                    <?php echo Form::text('address',auth()->guard('client-web')->user()->address,[
                     'class'=>'form-control text-right','placeholder'=>'العنوان'
                    ]); ?>

                </div>
                <div class="form-group text-right">
                    <label class="text-light-green">كلمة المرور</label>
                    <?php echo Form::text('password',null,[
                     'class'=>'form-control text-right',
                    ]); ?>

                </div>

                <button type="submit" class="btn btn-block text-white">تحديث</button>
            </form>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\system\fruit_ring\resources\views/front/profileclient.blade.php ENDPATH**/ ?>