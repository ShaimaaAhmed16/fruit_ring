<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>


    <section class=" pt-5 container-menu">
        <div class="container">
            <div class="row">
                <div class="col-12 ml-5">
                    <?php echo Form::open(['action'=>'Front\MainController@index','method'=>'get']); ?>

                    <div class="searchContainer w-75 float-left ml-5 col-10" >
                        <i class="fa fa-search searchIcon"></i>
                        <input class="bg-gray searchBox form-control" type="search" name="name">
                    </div>
                    <button class="btn  mt-1 ml-2 col-1" type="submit"><i class="fa fa-search"></i></button>

                        <?php echo Form::close(); ?>

                </div>
            </div>

            <div class="row pt-2 pb-1">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-4 text-center">
                    <?php echo Form::open(['action'=>'Front\MainController@index','method'=>'get']); ?>


                    <input class=" form-control " type="hidden" name="category_id" value="<?php echo e($category->id); ?>">
                    <button type="submit" class="text-white border-0  " style="background-color:#8cc540">
                        <i class="fab fa-pagelines"></i><br>
                        <span><?php echo e($category->name); ?></span>
                    </button>

                    <?php echo Form::close(); ?>

                </div> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>

    </section>

    
    <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="container mt-2 filter card">

        <div class="row p-2">
            <div class="col-6">
                <a href="<?php echo e(route('main')); ?>"><i class="fas fa-th-large mr-2"></i></a>
                <a href="<?php echo e(route('index')); ?>"><i class="fas fa-th-list text-light-green"></i></a>


            </div>
            <div class="col-6 text-right">
                <a href="<?php echo e(route('filter')); ?>"><i class="fas fa-filter mr-2"></i>
                    <span>فلتر</span></a>

            </div>
        </div>
    </section>

    <?php if(count($rows)): ?>
    <div id="" class="container mt-2 content">

        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-2">
            <div class="row p-2">
               <?php if(auth('client-web')->user()): ?>
                    <div class="col-4">
                    <a href="#"><i class="fab fa-opencart"></i></a><br>
                    <form action="<?php echo e(url('add-cart')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" value="<?php echo e($row->id); ?>">
                        <input type="hidden" name="name" value="<?php echo e($row->name); ?>">
                        <input type="hidden" name="price" value="<?php echo e($row->price); ?>">
                        <button type="submit" class="btn bg-light-green mt-4">شراء الآن</button>
                    </form>
                    </div>

                   <?php else: ?>
                    <div class="col-4">
                        <a href="#"><i class="fab fa-opencart"></i></a><br>
                        <button class="btn bg-light-green mt-4 myBtn2"> شراء الآن</button>
                    </div>
                   <?php endif; ?>
                <div class="col-4 text-right">
                    <h5><?php echo e($row->name); ?></h5>
                    <small>
                        ريال
                        <?php echo e($row->price); ?>

                    </small><br>
                    <span class="ml-4"><?php echo e($row->wight); ?></span>
                    <span class="text-light-green"><?php echo e($row->price); ?>ريال</span>
                </div>
                <div class="col-4 text-right">
                    <?php if(auth()->guard('client-web')->check()): ?>
                    <a href="<?php echo e(url('favorite/'.$row->id)); ?>">
                        <i class="
                        <?php if(auth('client-web')->user()->products()->find($row->id)): ?>
                            fas
                        <?php else: ?>
                            far
                        <?php endif; ?>
                            fa-heart"></i>
                    </a> <?php endif; ?>
                    <a href="<?php echo e(route('details',$row->id)); ?>">
                    <img src="<?php echo e(asset($row->image)); ?>" alt="" width="120">
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo $rows->render(); ?>


    </div>

    <?php else: ?>
        <div class="alert alert-danger text-center mt-5" role="alert">
            لا يوجد منتجات بهذا الاسم
        </div>
    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\system\fruit_ring\resources\views/front/index.blade.php ENDPATH**/ ?>