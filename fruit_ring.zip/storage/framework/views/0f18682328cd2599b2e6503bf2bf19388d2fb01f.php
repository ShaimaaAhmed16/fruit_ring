<?php $client = app('App\Models\Client'); ?>
<?php $product = app('App\Models\Product'); ?>
<?php $category = app('App\Models\Category'); ?>
<?php $contact = app('App\Models\Contact'); ?>

<?php $__env->startSection('page_title'); ?>
    لوحه التحكم
<?php $__env->stopSection(); ?>
<?php $__env->startSection('small_title'); ?>
    الاحصائيات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box">
                    <span class="info-box-icon bg-info"><i class="fa fa-user"></i></span>

                    <div class="info-box-content">
                        <span >مستخدمين</span>
                        <span class="info-box-number"><?php echo e($client->count()); ?></span>
                    </div>
                    <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
            </div>
            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box">
                    <span class="info-box-icon"> <i class="fa fa-book"></i></span>

                    <div class="info-box-content">
                        <span >منتجات</span>
                        <span class="info-box-number"><?php echo e($product->count()); ?></span>
                    </div>
                    <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
            </div>

            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box">
                    <span class="info-box-icon"> <i class="fa fa-align-justify"></i></span>

                    <div class="info-box-content">
                        <span >التصنيف</span>
                        <span class="info-box-number"><?php echo e($category->count()); ?></span>
                    </div>
                    <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
            </div>

            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box">
                    <span class="info-box-icon"> <i class="fa fa-envelope-square"></i></span>

                    <div class="info-box-content">
                        <span >التواصل بنا</span>
                        <span class="info-box-number"><?php echo e($contact->count()); ?></span>
                    </div>
                    <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\system\fruit_ring\resources\views/admin/index.blade.php ENDPATH**/ ?>