<?php $__env->startSection('page_title'); ?>
   عرض منتجات
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
        <!-- Default box -->
        <div class="card">

            <div class="card-body">
                <a href="<?php echo e(url(route('product.create'))); ?>" class="btn btn-primary"><i class="fa fa-plus"></i>اضافه منتج جديد</a>

                <div class="mt-3 text-right">
                    <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <?php if(count($records)): ?>
                    <div class="row">
                    <div class="table table-responsive">
                        <table class="table table-bordered text-center">
                           <thead>
                               <tr>
                                   <th>#</th>
                                   <th>الاسم</th>
                                   <th>السعر</th>
                                   <th>الوزن</th>
                                   <th>التصنيف</th>
                                   <th>صوره المنتج</th>
                                   <th>تعديل</th>
                                   <th>حذف</th>
                               </tr>
                           </thead>
                            <tbody>
                                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($loop->iteration); ?></th>
                                        <th><?php echo e($record->name); ?></th>
                                        <th><?php echo e($record->price); ?></th>
                                        <th><?php echo e($record->wight); ?></th>
                                        <th><?php echo e(optional($record->category)->name); ?></th>
                                        <th><img src="<?php echo e(asset($record->image)); ?>" width="60" height="60"></th>
                                        <th>
                                            <a href="<?php echo e(url(route('product.edit',$record->id))); ?>" class="btn btn-primary btn-xs" alt="تعديل المنتج"><i class="fa fa-edit"></i></a>
                                        </th >
                                        <th>
                                            <?php echo Form::open(['action'=>['Admin\ProductController@destroy',$record->id],'method'=>'delete']); ?>

                                            <button class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button>
                                            <?php echo Form::close(); ?>

                                        </th>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-danger" role="alert">
                        No data
                    </div>
                    </div>
                <?php endif; ?>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\system\fruit_ring\resources\views/admin/product/index.blade.php ENDPATH**/ ?>