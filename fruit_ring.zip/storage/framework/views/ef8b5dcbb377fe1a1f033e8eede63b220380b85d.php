<div class="form-group ">
    <label for="name">اسم التصنيف</label>
    <?php echo Form::text('name',null,[
        'class'=>'form-control text-right',"value"=>"<?php echo e(old('name')); ?>"
    ]); ?>


</div>

<div class="form-group">
    <button class="btn btn-primary" type="submit">حفظ</button>
</div><?php /**PATH C:\xampp\htdocs\system\fruit_ring\resources\views/admin/category/form.blade.php ENDPATH**/ ?>