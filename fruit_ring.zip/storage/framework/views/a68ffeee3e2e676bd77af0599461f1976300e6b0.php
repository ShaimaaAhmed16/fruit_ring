<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/app.css')); ?>">
    <title>الثمار الوطنيه جده</title>
</head>
<body>



<?php echo $__env->yieldContent('content'); ?>


<?php echo $__env->make('front.nave', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="<?php echo e(asset('front/js/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/bootstrap.min.js')); ?>"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="<?php echo e(asset('front/js/main.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\system\fruit_ring\resources\views/front/app.blade.php ENDPATH**/ ?>