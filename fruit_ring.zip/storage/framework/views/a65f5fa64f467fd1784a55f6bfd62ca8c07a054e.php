<?php $__env->startSection('content'); ?>

    <section class="container text-center pt-3">
        <img src="<?php echo e(asset('front/images/tt.png')); ?>" alt="" width="150">
    </section>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger text-right">
            <ul class="">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="signin">
        <div class="card pt-3">
            <form class="container" method="post" action="<?php echo e(route('login.client')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group text-right">

                    <input type="email" class="form-control text-right" placeholder="البريد الالكترونى" name="email">
                </div>
                <div class="form-group text-right">

                    <input type="password" class="form-control text-right"placeholder="كلمة المرور" name="password">
                </div>
                <div class="form-check text-center mt-4 mb-4">
                    <label class="form-check-label mr-4">
                        التسجيل التلقائى
                    </label>
                    <input class="form-check-input mr-3" type="checkbox" value="التسجيل التلقائى" >

                </div>
                <div class="text-center">
                    <button  type="submit" class="btn btn-block text-white bg-light-green mb-1">تسجيل الدخول</button>
                    <a href="<?php echo e(route('register.client')); ?>"  class="btn btn-block mb-1 text-white bg-black">تسجيل حساب جديد</a>
                </div>
                <div class="text-right">
                    <a href="<?php echo e(route('reset.password')); ?>"  class="btn text-white text-right bg-secondary">استعادة كلمة  المرور</a>
                </div><br>
                <hr>
                <div class="d-flex justify-content-around ">
                    <a href="#">
                        <i class="fab fa-google fa-2x text-danger"></i>
                    </a>
                    <a href="#">
                        <i class="fab fa-twitter fa-2x text-primary"></i>
                    </a>
                    <a href="#">
                        <i class="fab fa-facebook fa-2x text-blue"></i>
                    </a>
                </div>

            </form>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\system\fruit_ring\resources\views/front/login.blade.php ENDPATH**/ ?>