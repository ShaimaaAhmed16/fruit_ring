<?php $model = app('App\Models\Product'); ?>
<?php $__env->startSection('page'); ?>
    <a href="<?php echo e(url(route('product.index'))); ?>">منتجات</a>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_title'); ?>
   اضافه منتج
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
        <!-- Default box -->
        <div class="card">

            <div class="card-body text-right">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($error); ?><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
               <?php echo Form::model($model,['action'=>'Admin\ProductController@store',
               'method' => 'post',
               'files'=>true]); ?>


                    <?php echo $__env->make('admin.product.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo Form::close(); ?>

            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\system\fruit_ring\resources\views/admin/product/create.blade.php ENDPATH**/ ?>