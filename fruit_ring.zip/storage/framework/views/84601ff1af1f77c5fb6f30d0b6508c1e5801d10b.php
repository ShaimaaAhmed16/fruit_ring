<?php $model = app('App\Models\Client'); ?>
<?php $__env->startSection('page_title'); ?>
    عرض المستخدمين
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content ">
        <!-- Default box -->
        <div class="card">
            <div class="row margin-bottom">
                <div class="col-sm-6 ">
                    <a href="<?php echo e(url(route('client.create'))); ?>" class="btn btn-primary"><i class="fa fa-plus"></i>اضافه مستخدم جديد</a>

                </div>
                <div class="text-right col-sm-6">
                    <?php echo Form::open(['action'=>'Admin\ClientController@index','method'=>'get']); ?>

                    <input type="text" name="name" placeholder="الاسم" class="text-right">
                    <button class="btn btn-primary " type="submit"><i class="fa fa-search"></i> بحث</button>
                    <?php echo Form::close(); ?>


                </div>
            </div>
            <div class="card-body ">
                <div class="mt-3 text-right">
                    <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <?php if(count($records)): ?>
                    <div class="table table-responsive">
                        <table class="table table-bordered text-center">
                           <thead>
                               <tr>
                                   <th>#</th>
                                   <th>الاسم</th>
                                   <th>رقم الهاتف</th>
                                   <th>البريد</th>
                                   <th>الصوره</th>
                                   <th>عرض</th>
                                   <th>الحاله</th>
                                   <th>تعديل</th>
                                   <th>حذف</th>
                               </tr>
                           </thead>
                            <tbody>
                                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr id="removable<?php echo e($record->id); ?>">
                                        <th><?php echo e($loop->iteration); ?></th>
                                        <th><?php echo e($record->full_name); ?></th>
                                        <th><?php echo e($record->phone); ?></th>
                                        <th><?php echo e($record->email); ?></th>
                                        <th>
                                            <?php if($record->image): ?>
                                            <img  style="height: 70px;width: 70px;" src="<?php echo e(asset($record->image)); ?>" >
                                             <?php else: ?>
                                            <span>لايوجد صوره</span>
                                                <?php endif; ?>
                                        </th>
                                        <th> <a href="<?php echo e(url(route('client.show',$record->id))); ?>" class="btn btn-primary btn-xs"><i class="fas fa-eye"></i></a>
                                        </th>
                                        <th>
                                            <?php if($record->status == 0): ?>
                                                <a href="client/<?php echo e($record->id); ?>/active" class="btn btn-danger btn-xs">منتظر</a>
                                                <?php else: ?>
                                                <a href="client/<?php echo e($record->id); ?>/deactive" class="btn btn-success btn-xs" >مفعل</a>
                                                <?php endif; ?>
                                        </th >
                                        <th>
                                            <a href="<?php echo e(url(route('client.edit',$record->id))); ?>" class="btn btn-primary btn-xs" alt="تعديل المنتج"><i class="fa fa-edit"></i></a>
                                        </th >
                                        <th>
                                    
                                            <?php echo Form::open(['action'=>['Admin\ClientController@destroy',$record->id],'method'=>'delete']); ?>


                                            <button class="btn btn-danger btn-xs destroy"><i class="fa fa-trash"></i></button>
                                            <?php echo Form::close(); ?>

                                        </th>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-danger" role="alert">
                        لا يوجد مستخدم بهذا الاسم
                    </div>
                <?php endif; ?>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\system\fruit_ring\resources\views/admin/client/index.blade.php ENDPATH**/ ?>