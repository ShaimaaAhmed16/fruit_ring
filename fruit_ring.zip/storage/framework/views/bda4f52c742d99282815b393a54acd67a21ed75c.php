<nav class="navbar fixed-bottom text-center row bg-gray">
    <?php if(auth('client-web')->user()): ?>
        <div class="nav-item nav-link col">
            <div>
                <i class="far fa-user-circle text-silver"></i>
            </div>
            <a href="<?php echo e(route('myacount')); ?>" class="text-silver">
                <small>
                    حسابى
                </small>
            </a>
        </div>

    <?php else: ?>
        <div class="nav-item nav-link col">
            <div>
                <i class="far fa-user-circle text-silver"></i>
            </div>
            <a href="#" class="text-silver myBtn2">
                <small>
                    حسابى
                </small>
            </a>
        </div>
    <?php endif; ?>

    <div class="nav-item nav-link col">
        <div>
            <i class="fas fa-shopping-basket text-silver"></i> <?php if(Cart::count() > 0): ?>
            <span class="badge ml-1"><?php echo e(Cart::count()); ?> <?php endif; ?></span>
        </div>
        <a href="<?php echo e(route('cart')); ?>" class="text-silver">
            <small>
                سلة الشراء
            </small>
        </a>
    </div>
    <div class="nav-item nav-link col">
        <div>
            <i class="fas fa-apple-alt text-silver"></i>
        </div>
        <a href="<?php echo e(route('product.pransh')); ?>" class="text-silver">
            <small>
                منتجاتنا
            </small>
        </a>
    </div>
    <div class="nav-item nav-link col">
        <div>
            <i class="fas fa-store-alt text-silver"></i>
        </div>
        <a href="<?php echo e(route('product.pransh')); ?>" class="text-silver">
            <small>
                الرئيسية
            </small>
        </a>
    </div>

</nav><?php /**PATH C:\xampp\htdocs\system\fruit_ring\resources\views/front/nave.blade.php ENDPATH**/ ?>