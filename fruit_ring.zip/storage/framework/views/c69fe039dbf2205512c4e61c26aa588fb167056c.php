<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container shopcart">
        <section class="d-flex justify-content-between mt-5 pl-4">
            <button type="button" class="btn" data-toggle="modal" data-target="#Modal">
                إفراغ السلة
            </button>
            <!-- Modal -->
            <div class="modal fade" id="Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">

                        <div class="modal-body">
                            هل أنت متأكد
                        </div>
                        <div class="modal-footer justify-content-between">
                            <button type="button" class="btn" data-dismiss="modal">إلغاء</button>
                            <a href="<?php echo e(route('empty')); ?>" type="button" class="btn">متأكد </a>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <?php if(session()->has('success_message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('success_message')); ?>

                    </div>
                <?php endif; ?>

                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
            <?php if(Cart::count() > 0): ?>
                <label class="mt-2 pr-2"> عدد المنتجات : <?php echo e(Cart::count()); ?> </label>
        </section>

        <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <section class="text-center mt-5">
            <div class="card">
                <div class="row">
                    <div class="col-2">
                        <div class="card m-2 true">
                            <span class="pt-1 pb-1">&#10004;</span>
                        </div>
                        
                            
                        
                        <form action="<?php echo e(url('remove/'.$item->rowId)); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>


                            <button type="submit" class="border-0 btn-light"><i class="fas fa-trash-alt text-dark"></i></button>
                        </form>
                    </div>
                    <div class="col-5">
                        <div class="btn-group mr-2 mt-2">
                            <form action="<?php echo e(url('update-quantity/'.$item->rowId)); ?>" method="get">
                                <?php echo csrf_field(); ?>
                                
                                <select class="quantity" data-id="rowId " data-productQuantity="quantity " name="quantity">
                                    <?php for($i = 1; $i <10 + 1 ; $i++): ?>
                                        <option <?php echo e($item->qty == $i ? 'selected' : ''); ?> ><?php echo e($i); ?></option>
                                    <?php endfor; ?>
                                </select>
                                <button type="submit" ><i class="fas fa-pencil-alt"></i></button>
                            </form>

                        </div>
                    </div>
                    <div class="col-5 d-flex justify-content-around">
                        <h5 class="pt-3"><?php echo e($item->name); ?></h5>
                        <div class="img mt-2">
                            <img src="<?php echo e(asset($item->model->image)); ?>" alt="" width="50" height="50" class="p-1">
                        </div>


                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-6">
                        <span>
                            السعر : <?php echo e($item->price); ?>  ر.س
                        </span>
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    <div class="col-6 mb-1">
                        <span>
                            الوزن :  <?php echo e($item->model->wight); ?>

                        </span>
                        <i class="fas fa-weight fa-2x ml-2"></i>
                    </div>
                </div>
            </div>
        </section>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <form method="get" action="<?php echo e(route('addorder')); ?>">
        <section class="text-center mt-5">
            <div><p class="bg-success text-white pl-5 pr-5 pt-1 pb-1" >ر.س<?php echo e(Cart::subtotal()); ?> المجموع الكلي</p></div>
        </section>
            <button type="submit" class="bg-success text-white pl-5 pr-5 pt-1 pb-1 w-100 border-0" style="margin-bottom: 70px">ارسال الطلب</button>
        </form>
    <?php else: ?>
        <section class="text-center mt-5">
            <label class="bg-red text-white pl-5 pr-5 pt-1 pb-1">لايوجد منتجات فى السلة</label>
        </section>
        <?php endif; ?>


    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\system\fruit_ring\resources\views/front/cart.blade.php ENDPATH**/ ?>