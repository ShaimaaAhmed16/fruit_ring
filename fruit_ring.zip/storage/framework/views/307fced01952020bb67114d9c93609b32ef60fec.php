<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<section class="contact container">
    <div class="card text-right pr-4">
        <div class="row">
            <div class="col-12">
                <small><?php echo e($row->name); ?></small>
                <i class="fas fa-globe text-light-green ml-2"></i>
            </div>
            <div class="col-12">
                <small><?php echo e($row->phone); ?></small>
                <i class="fas fa-mobile text-light-green ml-2"></i>
            </div>
            <div class="col-12">
                <small><?php echo e($row-> watsUp); ?></small>
                <i class="fab fa-whatsapp text-light-green ml-2"></i>
            </div>
            <div class="col-12">
                <small><?php echo e($row->email); ?></small>
                <i class="fas fa-envelope text-light-green ml-2"></i>
            </div>
        </div>
    </div>

    <form method="post" action="<?php echo e(route('contact.client')); ?>">
        <?php echo csrf_field(); ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger text-right ">
                <ul class="">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($error); ?><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="form-group text-right">

            <input type="text" class="form-control" placeholder="الاسم" name="name">
        </div>
        <div class="form-group text-right">

            <input type="tel" class="form-control"placeholder="رقم الجوال" name="phone">
        </div>
        <div class="form-group text-right">

            <input type="email" class="form-control" placeholder="username.gmail.com" name="email">
        </div>
        <div class="form-group text-right">
            <textarea class="form-control" placeholder="نص الرسالة" name="message"></textarea>
        </div>

        <button  type="submit" id="myBtn3" class="btn btn-block text-white" >ارسال</button>

    </form>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\system\fruit_ring\resources\views/front/contact.blade.php ENDPATH**/ ?>