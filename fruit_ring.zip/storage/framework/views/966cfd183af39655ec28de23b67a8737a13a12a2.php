<div class="form-group ">
    <label for="name">اسم المنتج</label>
    <?php echo Form::text('name',null,[
        'class'=>'form-control text-right',"value"=>"<?php echo e(old('name')); ?>"
    ]); ?>

    <label for="price">سعر المنتج</label>
    <?php echo Form::text('price',null,[
        'class'=>'form-control text-right',"value"=>"<?php echo e(old('price')); ?>"
    ]); ?>


    <label for="wight">وزن المنتج</label>
    <?php echo Form::text('wight',null,[
        'class'=>'form-control text-right',"value"=>"<?php echo e(old('wight')); ?>"
    ]); ?>

    <label for="">اختار التصنيف</label>
    <?php echo Form::select('category_id',$categories->pluck('name','id')->toArray(),null,[
        'class'=>'form-control text-right'
    ]); ?>

    <label for="Image" class="btn-block">صوره المنتج</label>
    <?php if($model->image): ?>
    <img src="<?php echo asset($model->image)?>"/>
    <?php endif; ?>
    <br>
    <?php echo Form::file('image',null,[
        'class'=>'form-control file_upload_preview'
    ]); ?>



</div>

<div class="form-group">
    <button class="btn btn-primary" type="submit">حفظ</button>
</div><?php /**PATH C:\xampp\htdocs\system\fruit_ring\resources\views/admin/product/form.blade.php ENDPATH**/ ?>